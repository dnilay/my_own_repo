package com.example.groupdashboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroupDashboardApplicationTests {

    @Test
    void contextLoads() {
    }

}
